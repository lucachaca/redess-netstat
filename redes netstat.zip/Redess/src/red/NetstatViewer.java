package red;

import javax.swing.*;
import java.awt.*;

public class NetstatViewer extends JFrame {

    private JTextArea area;

    public NetstatViewer() {
        setTitle("Netstat Viewer");
        setSize(600, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        area = new JTextArea();
        area.setEditable(false);
        JScrollPane scroll = new JScrollPane(area);

        JPanel botones = new JPanel(new FlowLayout());
        JButton btnA = new JButton("netstat -a");
        JButton btnE = new JButton("netstat -e");
        JButton btnPTCP = new JButton("netstat -p tcp");

        btnA.addActionListener(e -> mostrar(" -a"));
        btnE.addActionListener(e -> mostrar(" -e"));
        btnPTCP.addActionListener(e -> mostrar(" -p tcp"));

        botones.add(btnA);
        botones.add(btnE);
        botones.add(btnPTCP);

        add(botones, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);
    }

    private void mostrar(String args) {
        area.setText("Cargando " + args + "...\n");
        SwingWorker<Void, Void> worker = new SwingWorker<>() {
            String resultado;

            @Override
            protected Void doInBackground() {
                resultado = EscaneoRed.ejecutarNetstat(args);
                return null;
            }

            @Override
            protected void done() {
                area.setText(resultado);
                area.setCaretPosition(0);
            }
        };
        worker.execute();
    }
}
