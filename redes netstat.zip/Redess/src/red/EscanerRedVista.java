package red;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.FileWriter;
import java.io.IOException;

/**
 * Clase que maneja la interfaz gráfica del escáner de red.
 */
public class EscanerRedVista {

    private JFrame ventana;
    private JTextField campoInicio, campoFin;
    private JTable tabla;
    private DefaultTableModel modelo;
    private JProgressBar barra;

    public JFrame crearInterfaz() {
        ventana = new JFrame("Escáner de Red");
        ventana.setSize(800, 450);
        ventana.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        ventana.setLocationRelativeTo(null);

        // Panel superior
        JPanel panel = new JPanel();
        campoInicio = new JTextField(12);
        campoFin = new JTextField(12);
        JButton botonEscanear = new JButton("Escanear");
        JButton botonLimpiar = new JButton("Limpiar");
        JButton botonGuardar = new JButton("Guardar");

        panel.add(new JLabel("IP Inicio:"));
        panel.add(campoInicio);
        panel.add(new JLabel("IP Fin:"));
        panel.add(campoFin);
        panel.add(botonEscanear);
        panel.add(botonLimpiar);
        panel.add(botonGuardar);

        // Tabla
        modelo = new DefaultTableModel();
        modelo.addColumn("IP");
        modelo.addColumn("Activo");
        modelo.addColumn("Tiempo (ms)");
        modelo.addColumn("Nombre Host");
        tabla = new JTable(modelo);

        // Barra de progreso
        barra = new JProgressBar();
        barra.setStringPainted(true);

        // Acciones
        botonEscanear.addActionListener(this::iniciarEscaneo);
        botonLimpiar.addActionListener(e -> modelo.setRowCount(0));
        botonGuardar.addActionListener(e -> guardarResultados());

        // Layout
        ventana.add(panel, BorderLayout.NORTH);
        ventana.add(new JScrollPane(tabla), BorderLayout.CENTER);
        ventana.add(barra, BorderLayout.SOUTH);

        ventana.setVisible(true);
        return ventana;
    }

    private void iniciarEscaneo(ActionEvent e) {
        String inicio = campoInicio.getText().trim();
        String fin = campoFin.getText().trim();

        if (!EscaneoRed.esIPValida(inicio) || !EscaneoRed.esIPValida(fin)) {
            JOptionPane.showMessageDialog(ventana, "IPs inválidas", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        new Thread(() -> escanearRango(inicio, fin)).start();
    }

    private void escanearRango(String ipInicio, String ipFin) {
        try {
            int desde = Integer.parseInt(ipInicio.substring(ipInicio.lastIndexOf('.') + 1));
            int hasta = Integer.parseInt(ipFin.substring(ipFin.lastIndexOf('.') + 1));
            String base = ipInicio.substring(0, ipInicio.lastIndexOf('.') + 1);

            barra.setMaximum(hasta - desde + 1);
            barra.setValue(0);
            modelo.setRowCount(0);

            for (int i = desde; i <= hasta; i++) {
                String ip = base + i;
                long tiempo;
                boolean activo;

                // Medimos el tiempo de ping
                long t0 = System.currentTimeMillis();
                activo = EscaneoRed.estaActivo(ip);
                long t1 = System.currentTimeMillis();
                tiempo = activo ? (t1 - t0) : -1;

                String host = activo ? EscaneoRed.obtenerNombreHost(ip) : "-";

                modelo.addRow(new Object[]{ip, activo ? "SI" : "NO", (tiempo >= 0 ? tiempo : "-"), host});
                barra.setValue(i - desde + 1);
            }

            barra.setString("Escaneo finalizado");

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(ventana, "Error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void guardarResultados() {
        if (modelo.getRowCount() == 0) {
            JOptionPane.showMessageDialog(ventana, "No hay datos para guardar", "Información", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        try (FileWriter fw = new FileWriter("resultado_ping.txt", true)) {
            for (int i = 0; i < modelo.getRowCount(); i++) {
                String ip = modelo.getValueAt(i, 0).toString();
                String activo = modelo.getValueAt(i, 1).toString();
                String tiempo = modelo.getValueAt(i, 2).toString();
                String host = modelo.getValueAt(i, 3).toString();
                fw.write(ip + " -> Activo: " + activo + ", Tiempo: " + tiempo + " ms, Host: " + host + "\n");
            }
            JOptionPane.showMessageDialog(ventana, "Resultados guardados en resultado_ping.txt");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(ventana, "Error al guardar archivo: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
