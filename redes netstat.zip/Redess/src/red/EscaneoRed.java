package red;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.InetAddress;

public class EscaneoRed {

    public static boolean estaActivo(String ip) {
        try {
            return InetAddress.getByName(ip).isReachable(1000);
        } catch (IOException e) {
            return false;
        }
    }

    public static boolean esIPValida(String ip) {
        return ip != null && ip.matches("(\\d{1,3}\\.){3}\\d{1,3}");
    }

    public static String obtenerNombreHost(String ip) {
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"nslookup", ip});
            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
            String line;
            while ((line = br.readLine()) != null) {
                String ln = line.trim().toLowerCase();
                if (ln.contains("name =")) {
                    return line.split("name =")[1].trim();
                }
            }
        } catch (Exception e) {
            return "-";
        }
        return "-";
    }

    public static String ejecutarNetstat(String argumentos) {
        StringBuilder salida = new StringBuilder();
        try {
            Process proceso = Runtime.getRuntime().exec("netstat " + argumentos);
            BufferedReader br = new BufferedReader(new InputStreamReader(proceso.getInputStream()));
            String linea;
            while ((linea = br.readLine()) != null) {
                salida.append(linea).append("\n");
            }
        } catch (IOException e) {
            salida.append("Error ejecutando netstat: ").append(e.getMessage());
        }
        return salida.toString();
    }
}
