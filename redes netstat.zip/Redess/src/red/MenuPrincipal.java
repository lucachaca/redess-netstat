package red;

import javax.swing.*;
import java.awt.*;

public class MenuPrincipal extends JFrame {

    public MenuPrincipal() {
        setTitle("Menú Principal");
        setSize(300, 150);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(2, 1, 10, 10));

        JButton btnEscaner = new JButton("Escáner de Red");
        JButton btnNetstat = new JButton("Netstat Viewer");

        btnEscaner.addActionListener(e -> {
            EscanerRedVista vista = new EscanerRedVista();
            vista.crearInterfaz(); // abre ventana del escáner
        });

        btnNetstat.addActionListener(e -> {
            NetstatViewer viewer = new NetstatViewer();
            viewer.setVisible(true); // abre ventana del netstat
        });

        add(btnEscaner);
        add(btnNetstat);
    }
}
